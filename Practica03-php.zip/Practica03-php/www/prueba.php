<?php

	$array = array('Pepe', 'Irene', 'Tomas');
	foreach($array as $i)
	{
		echo $i . "<br>";
	}
	
?>
